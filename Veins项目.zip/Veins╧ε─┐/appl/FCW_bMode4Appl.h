//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
//

/**
 * Mode4App is a new application developed to be used with Mode 4 based simulation
 * Author: Brian McCarthy
 * Email: b.mccarthy@cs.ucc.ie
 */

#ifndef _MY_MODE4APP_H_
#define _MY_MODE4APP_H_
#include "Brake_Function.h" //zhaofuhuan xiugai
#include "apps/mode4App/Mode4BaseApp.h"
#include "apps/alert/AlertPacket_m.h"
#include "corenetwork/binder/LteBinder.h"

//修改
#include "veins/modules/mobility/traci/TraCICommandInterface.h"
#include "veins_inet/VeinsInetMobility.h"
using veins::TraCICommandInterface;
using veins::VeinsInetMobility;
using veins::VeinsInetMobilityAccess;
class FCW_bMode4Appl : public Mode4BaseApp {

public:
    ~FCW_bMode4Appl() override;

protected:
    //sender
    int size_;
    int nextSno_;
    int priority_;
    int duration_;
    simtime_t period_;

    simsignal_t sentMsg_;
    simsignal_t delay_;
    simsignal_t rcvdMsg_;
    simsignal_t cbr_;

    cMessage *selfSender_;

    LteBinder* binder_;
    MacNodeId nodeId_;
    VeinsInetMobility* mobility;
    TraCICommandInterface* traci;
    TraCICommandInterface::Vehicle* traciVehicle;
    Brake_Function* function_1;  //zhaofuhuan xiugai
    double vehicle_cur_decel=0;//zhaofuhuan
    std::string vehicle_id_tx;
    double brake_1;//zhaofuhuan
    double brake_2=0;//zhaofuhuan
    int iiii=0;
    double distance_ab=0;
    double speed_a=0;
    double vehilce_curSpeed_tx=25;
    double vehicle_2_speed_x=25;
    simtime_t first_packet_time;
    simtime_t last_packet_time;
    double ratio=0;//pdr
    int ii=0;
    double p1=0.6019;
    double p2=0.4821;
    double p3=0.3421;
   int numInitStages() const { return inet::NUM_INIT_STAGES; }

   /**
    * Grabs NED parameters, initializes gates
    * and the TTI self message
    */
   void initialize(int stage);

   void handleLowerMessage(cMessage* msg);


   /**
    * Statistics recording
    */
   void finish();

   /**
    * Main loop of the Mac level, calls the scheduler
    * and every other function every TTI : must be reimplemented
    * by derivate classes
    */
   void handleSelfMessage(cMessage* msg);

   /**
    * sendLowerPackets() is used
    * to send packets to lower layer
    *
    * @param pkt Packet to send
    */
   void sendLowerPackets(cPacket* pkt);

};

#endif
