/*
 * MyMode4Appl.cc
 *
 *  Created on: Nov 5, 2020
 *      Author: hacker
 */

/**
 * Mode4App is a new application developed to be used with Mode 4 based simulation
 * Author: Brian McCarthy
 * Email: b.mccarthy@cs.ucc.ie
 */

/*#include "BSWMode4Appl.h"
#include "common/LteControlInfo.h"
#include "stack/phy/packet/cbr_m.h"
#include "MyMesseage_m.h"
#include "veins/base/utils/FindModule.h"
#include "veins/base/modules/BaseModule.h"
#include "veins/veins.h"
#include "veins/base/utils/HostState.h"
#include "veins/modules/mobility/traci/TraCIColor.h"


Define_Module(BSWMode4Appl);

using veins::TraCICommandInterface;
using veins::VeinsInetMobility;

using veins:: FindModule;
using veins::TraCIColor;
//using veins:: BaseModule;

void BSWMode4Appl::initialize(int stage)
{
    Mode4BaseApp::initialize(stage);
    if (stage==inet::INITSTAGE_LOCAL){
        // Register the node with the binder
        // Issue primarily is how do we set the link layer address

        // Get the binder
        binder_ = getBinder();

        // Get our UE
        cModule *ue = getParentModule();

        //Register with the binder
        nodeId_ = binder_->registerNode(ue, UE, 0);

        // Register the nodeId_ with the binder.
        binder_->setMacNodeId(nodeId_, nodeId_);
        if (FindModule<VeinsInetMobility*>::findSubModule(getParentModule())) {
                 mobility = VeinsInetMobilityAccess().get(getParentModule());
                 traci = mobility->getCommandInterface();
                 traciVehicle = mobility->getVehicleCommandInterface();
                 EV<<"FindModule<TraCIMobility*>::findSubModule(getParentModule())"<<endl;
       }
    } else if (stage==inet::INITSTAGE_APPLICATION_LAYER) {
        selfSender_ = NULL;
        nextSno_ = 0;

        selfSender_ = new cMessage("selfSender");

        size_ = par("packetSize");
        period_ = par("period");
        priority_ = par("priority");
        duration_ = par("duration");

        sentMsg_ = registerSignal("sentMsg");
        delay_ = registerSignal("delay");
        rcvdMsg_ = registerSignal("rcvdMsg");
        cbr_ = registerSignal("cbr");

        double delay = 0.001 * intuniform(0, 1000, 0);
        scheduleAt((simTime() + delay).trunc(SIMTIME_MS), selfSender_);
    }
}

void BSWMode4Appl::handleLowerMessage(cMessage* msg)
{
    if (msg->isName("CBR")) {
        Cbr* cbrPkt = check_and_cast<Cbr*>(msg);
        double channel_load = cbrPkt->getCbr();
        emit(cbr_, channel_load);
        deK1*pow(distance_cha,3)+K2*distance_cha+K3lete cbrPkt;
    } else {
        //AlertPacket* pkt = check_and_cast<AlertPacket*>(msg);
        //veins::MyMesseage *pkt = check_and_cast<veins::MyMesseage*>(msg);
        //inet::MyMesseage *pkt = check_and_cast<inet::MyMesseage*>(msg);
        MyMesseage *pkt = check_and_cast<MyMesseage*>(msg);

        if (pkt == 0)
        {
            throw cRuntimeError("Mode4App::handleMessage - FATAL! Error when casting to AlertPacket");
        }
        else
        {
            if(abs(mobility->getCurrentPosition().x) <= abs(pkt->getCur_position_tx_x()))
            {
                double vehicle_0_position_x = pkt->getCur_position_tx_x();
                double vehicle_0_position_y = pkt->getCur_position_tx_y();
                double vehicle_1_position_x = mobility->getCurrentPosition().x;
                double vehicle_1_position_y = mobility->getCurrentPosition().y;
                double DIS1 = abs(vehicle_0_position_x-vehicle_1_position_x);//两车前后车距
                double DIS2 = abs(vehicle_0_position_y-vehicle_1_position_y);//两车左右车距
                if(DIS1<=15&&pkt->getLanechange()==true&&DIS2>2)//判断前后车距和左右车距，并判断前车是否有发送变道消息
                {
                    getParentModule()->getDisplayString().updateWith("r=80,pink");
                    traciVehicle->setColor(TraCIColor(255, 255, 255, 255));//后车变色
                    traciVehicle->setSpeed(5);//后车减速
                }
                if(DIS1>30&&DIS2==0)//判断前后车距安全且前车变道完成
                {
                    traciVehicle->setColor(TraCIColor(255, 255, 0, 255));//后车恢复颜色
                    traciVehicle->setSpeed(30);//后车恢复速度行驶
                }
            }

        }

        // emit statistics
        simtime_t delay = simTime() - pkt->getTimestamp();
        emit(delay_, delay);
        emit(rcvdMsg_, (long)1);

        EV << "Mode4App::handleMessage - Packet received: SeqNo[" << pkt->getSno() << "] Delay[" << delay << "]" << endl;

        delete msg;
    }
}

void BSWMode4Appl::handleSelfMessage(cMessage* msg)
{
    if (!strcmp(msg->getName(), "selfSender")){
        MyMesseage *packet = new MyMesseage("Alert");
        packet->setTimestamp(simTime());
        packet->setByteLength(size_);
        packet->setSno(nextSno_);

        vehicle_id_tx = mobility->getExternalId();

        double vehicle_curPosition_tx_x = mobility->getCurrentPosition().x;
        double vehicle_curPosition_tx_y = mobility->getCurrentPosition().y;
        if(simTime()>=3&&simTime()<=5)
        {
           packet->setLanechange(true);
        }
        packet->setVehicle_id(vehicle_id_tx.c_str());
        packet->setCur_position_tx_x(vehicle_curPosition_tx_x);
        packet->setCur_position_tx_y(vehicle_curPosition_tx_y);



        nextSno_++;

        auto lteControlInfo = new FlowControlInfoNonIp();

        lteControlInfo->setSrcAddr(nodeId_);
        lteControlInfo->setDirection(D2D_MULTI);
        lteControlInfo->setPriority(priority_);
        lteControlInfo->setDuration(duration_);
        lteControlInfo->setCreationTime(simTime());

        packet->setControlInfo(lteControlInfo);

        Mode4BaseApp::sendLowerPackets(packet);
        emit(sentMsg_, (long)1);

        scheduleAt(simTime() + period_, selfSender_);
    }
    else
        throw cRuntimeError("Mode4App::handleMessage - Unrecognized self message");
}

void BSWMode4Appl::finish()
{
    cancelAndDelete(selfSender_);
}

BSWMode4Appl::~BSWMode4Appl()
{
    binder_->unregisterNode(nodeId_);
}
*/


#include "Brake_Function.h"
#include <cmath>
#include<iostream>
using namespace std;


double Brake_Function:: brake_function_1(double speed){
        int K1=4;
        int K2=50;
        int K3=6000;
        int F_brake_max=10000;
        double b0=0.43;
        double a0_m_g=150*9.81;
        double F_distance;
        double F_speed;
        double Brake;
        Brake=a0_m_g+b0*pow(speed,2)+F_brake_max;
        return Brake;
   }
double Brake_Function:: brake_function_2(double distance_cha,double b_speed){
        int K1=4;
        int K2=50;
        int K3=6000;
        int F_brake_max=10000;
        double b0=0.43;
        double a0_m_g=150*9.81;
        double F_distance;
        double F_speed;
        double Brake;
        if(K1*pow(40-distance_cha,3)+K2*(40-distance_cha)+K3<=F_brake_max)
                F_distance=K1*pow(40-distance_cha,3)+K2*(40-distance_cha)+K3;

        else
                F_distance=F_brake_max;

        Brake=a0_m_g+b0*pow(b_speed,2)+F_distance;
        return Brake;

    }
double Brake_Function:: brake_function_3(double distance_cha,double a_speed,double b_speed){
        int K1=4;
        int K2=50;
        int K3=6000;
        int F_brake_max=10000;
        double b0=0.43;
        double a0_m_g=150*9.81;
        double F_distance;
        double F_speed;
        double Brake;
        if(K1*pow(40-distance_cha,3)+K2*(40-distance_cha)+K3<=F_brake_max)
                F_distance=K1*pow(40-distance_cha,3)+K2*(40-distance_cha)+K3;

        else
                F_distance=F_brake_max;

        if(K1*pow(25-a_speed,3)+K2*(25-a_speed)+K3<=F_brake_max)
                F_speed=K1*pow(25-a_speed,3)+K2*(25-a_speed)+K3;

        else
                F_speed=F_brake_max;

        Brake=a0_m_g+b0*pow(b_speed,2)+0.5*F_distance+0.5*F_speed;
        return Brake;

    }

double Brake_Function:: brake_function_4(double distance_cha,double a_speed,double b_speed){
        int K1=4;
        int K2=50;
        int K3=6000;
        int F_brake_max=10000;
        double b0=0.43;
        double a0_m_g=150*9.81;
        double F_distance;
        double F_speed;
        double Brake;
        if(K1*pow(40-distance_cha,3)+K2*(40-distance_cha)+K3<=F_brake_max)
                F_distance=K1*pow(40-distance_cha,3)+K2*(40-distance_cha)+K3;

        else
                F_distance=F_brake_max;

        if(K1*pow(25-a_speed,3)+K2*(25-a_speed)+K3<=F_brake_max)
                F_speed=K1*pow(25-a_speed,3)+K2*(25-a_speed)+K3;

        else
                F_speed=F_brake_max;

        Brake=a0_m_g+b0*pow(b_speed,2)+0.333333*F_distance+0.333333*F_speed+0.333333*F_brake_max;
        return Brake;

    }

//




