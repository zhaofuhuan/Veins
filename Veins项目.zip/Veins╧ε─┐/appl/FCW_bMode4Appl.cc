/*
 * MyMode4Appl.cc
 *
 *  Created on: Nov 5, 2020
 *      Author: hacker
 */

/**
 * Mode4App is a new application developed to be used with Mode 4 based simulation
 * Author: Brian McCarthy
 * Email: b.mccarthy@cs.ucc.ie
 */

#include "FCW_bMode4Appl.h"
#include "common/LteControlInfo.h"
#include "stack/phy/packet/cbr_m.h"
#include "MyMesseage_m.h"
#include "veins/base/utils/FindModule.h"
#include <cmath>
Define_Module(FCW_bMode4Appl);

using veins::TraCICommandInterface;
using veins::VeinsInetMobility;

using veins:: FindModule;
using veins:: TraCIColor;


void FCW_bMode4Appl::initialize(int stage)
{
    Mode4BaseApp::initialize(stage);
    if (stage==inet::INITSTAGE_LOCAL){
        // Register the node with the binder
        // Issue primarily is how do we set the link layer address

        // Get the binder
        binder_ = getBinder();

        // Get our UE
        cModule *ue = getParentModule();

        //Register with the binder
        nodeId_ = binder_->registerNode(ue, UE, 0);

        // Register the nodeId_ with the binder.
        binder_->setMacNodeId(nodeId_, nodeId_);
        if (FindModule<VeinsInetMobility*>::findSubModule(getParentModule())) {
                 mobility = VeinsInetMobilityAccess().get(getParentModule());
                 traci = mobility->getCommandInterface();
                 traciVehicle = mobility->getVehicleCommandInterface();
                 traciVehicle->setSpeedMode(0);
                 EV<<"FindModule<TraCIMobility*>::findSubModule(getParentModule())"<<endl;

       }
    } else if (stage==inet::INITSTAGE_APPLICATION_LAYER) {
        selfSender_ = NULL;
        nextSno_ = 0;

        selfSender_ = new cMessage("selfSender");

        size_ = par("packetSize");
        period_ = par("period");
        priority_ = par("priority");
        duration_ = par("duration");

        sentMsg_ = registerSignal("sentMsg");
        delay_ = registerSignal("delay");
        rcvdMsg_ = registerSignal("rcvdMsg");
        cbr_ = registerSignal("cbr");

        double delay = 0.001 * intuniform(0, 1000, 0);
        scheduleAt((simTime() + delay).trunc(SIMTIME_MS), selfSender_);
    }
}

void FCW_bMode4Appl::handleLowerMessage(cMessage* msg)
{
    if (msg->isName("CBR"))
    {
        Cbr* cbrPkt = check_and_cast<Cbr*>(msg);
        double channel_load = cbrPkt->getCbr();
        emit(cbr_, channel_load);
        delete cbrPkt;
    }
    else
    {

        MyMesseage *pkt = check_and_cast<MyMesseage*>(msg);

        if (pkt == 0)
        {
            throw cRuntimeError("Mode4App::handleMessage - FATAL! Error when casting to AlertPacket");
        }
        else
        {
            EV<<"receiver getVehicle_id = "<<pkt->getVehicle_id()<<endl;
            if(strncmp(pkt->getVehicle_id(),"vehicle_1",9)==0)  //此时vehicle_1发出信息，
            {
                if(strcmp(mobility->getExternalId().c_str(),"vehicle_2")==0)
                {
                   EV<<"vehicle_2 position is"<<mobility->getCurrentPosition()<<endl;

                   double vehicle_1_position_x = pkt->getCur_position_tx();  //发出信息的vehicle_1的位置信息
                   double vehicle_1_position_y = pkt->getCur_position_ty();
                   double vehicle_2_position_x = mobility->getCurrentPosition().x;  //vehicle_2的位置信息
                   double vehicle_2_position_y = mobility->getCurrentPosition().y;
                   double vehicle_1_speed_x=pkt->getSpeed();  //获取vehicle_1的x方向的速度
                   //double vehicle_2_speed_x=mobility->getCurrentSpeed().x;  //获取vehicle_2的x方向的速度
                   double relative_distance_x = abs(mobility->getCurrentPosition().x-pkt->getCur_position_tx());  //两车x方向的相对距离
                   double relative_distance_y = mobility->getCurrentPosition().y-pkt->getCur_position_ty();  //两车x方向的相对距离
                   double relative_speed = abs(pkt->getSpeed()-vehicle_2_speed_x);  //两车的相对速度
                   double Tx = abs( relative_distance_x / relative_speed );  //两车的碰撞时间
                 //if((simTime().dbl()-pkt->getTimestamp().dbl())<0.02)
                   //{
                   if(iiii==0)
                           first_packet_time=pkt->getTimestamp().dbl();
                   iiii+=1;
                   //}
                   double jjjj=(pkt->getTimestamp().dbl()-first_packet_time.dbl()+0.1)*10;
                   std::cout<<"接收  "<<iiii<<"当前发送  "<<jjjj<<"   PDR"<<iiii/jjjj<<" 差  ："<<jjjj-iiii<<endl;
                   std::cout<<"包内时间戳"<<(pkt->getTimestamp().dbl()-first_packet_time.dbl()+0.1)*10<<endl;
                   std::cout<<"车辆2当前速度： "<<mobility->getCurrentSpeed().x<<endl;
                   //两辆车在同一车道时

                   if(pkt->getCur_position_tx()>800)
                       ii+=1;
                   else
                       traciVehicle->setSpeed(25);
                   std::cout<<"ii的值： "<<ii<<endl;
                   std::cout<<"两车当前的距离为："<<pkt->getCur_position_tx()-mobility->getCurrentPosition().x<<endl;
                   if(relative_distance_y == 0&&(pkt->getCur_decel()>0)&&(ii>=1))
                   {    if(ratio==0)
                           ratio=iiii/jjjj;
                        std::cout<<"ratio的值： "<<ratio<<endl;
                        EV<<"vehicle1开始减速 消息包vehicle1减速度为 "<<pkt->getCur_decel();
                        getParentModule()->getDisplayString().updateWith("r=80,pink");
                        bubble("the vehicle will collide");
                        traciVehicle->setColor(TraCIColor(0, 255, 0, 255));
                        double interval;
                        if(last_packet_time.dbl()==0)
                        {   //std::cout<<"初始时间======"<<last_packet_time<<endl;
                            last_packet_time=simTime();
                            interval = (simTime()-pkt->getTimestamp()).dbl()+0.1;
                            std::cout<<"时间间隔："<<interval<<endl;
                        }
                        else
                        {
                            interval=(simTime()-last_packet_time).dbl();
                            last_packet_time=simTime();
                        }
                        //std::cout<<"包传输时延  "<<interval<<endl;


                        //std::cout<<"  当前vehicle1的速度为  "<<vehicle_2_speed_x<<endl;
                        if(brake_2==0)
                        {
                            if(ratio>p1)
                            {
                            brake_2=function_1->brake_function_2(relative_distance_x,vehicle_2_speed_x);
                            distance_ab=relative_distance_x;
                            speed_a=vehicle_1_speed_x;
                            std::cout<<"执行制动策略一"<<endl;
                            //std::cout<<"制动力  "<<brake_2<<endl;
                            //std::cout<<"  当前vehicle1的   减速度为  "<<brake_2<<endl;
                            //brake_2=function_1->brake_function_2(relative_distance_x,relative_speed);
                            }
                            else if(ratio>p2)
                            {
                                brake_2=function_1->brake_function_3(relative_distance_x,vehicle_1_speed_x,vehicle_2_speed_x);
                                distance_ab=relative_distance_x;
                                speed_a=vehicle_1_speed_x;
                                std::cout<<"执行制动策略二"<<endl;
                            }
                            else
                            {
                                brake_2=function_1->brake_function_4(relative_distance_x,vehicle_1_speed_x,vehicle_2_speed_x);
                                distance_ab=relative_distance_x;
                                speed_a=vehicle_1_speed_x;
                                std::cout<<"执行制动策略三"<<endl;
                            }
                        }
                        else
                        {   if(ratio>p1)
                            {
                                brake_2=function_1->brake_function_2(distance_ab,vehicle_2_speed_x );
                                std::cout<<"执行制动策略一"<<endl;
                            }
                            else if(ratio>p2)
                            {
                                brake_2=function_1->brake_function_3(distance_ab,speed_a,vehicle_2_speed_x);
                                std::cout<<"执行制动策略二"<<endl;
                            }
                            else
                            {
                                brake_2=function_1->brake_function_4(distance_ab,speed_a,vehicle_2_speed_x);
                                std::cout<<"执行制动策略三"<<endl;
                            }
                            std::cout<<"相对距离  "<<distance_ab<<endl;
                        }


                            if(vehicle_2_speed_x-brake_2/1500*interval>0.1)
                               {

                                vehicle_2_speed_x=vehicle_2_speed_x-(brake_2/1500*interval);
                                traciVehicle->setSpeed(vehicle_2_speed_x);
                                std::cout<<"shache qian brake："<<brake_2<<endl;
                                std::cout<<"dang qian juli:"<<relative_distance_x<<endl;
                                std::cout<<"刹车后车辆2速度："<<vehicle_2_speed_x<<"jian速度："<<(brake_2/1500*0.1)<<endl;
                               }
                            else
                               {
                                traciVehicle->setSpeed(0);
                                vehicle_2_speed_x=0;
                                std::cout<<"A车的行驶距离："<<vehicle_1_position_x-800<<endl;
                                std::cout<<"B车的行驶距离："<<vehicle_2_position_x-760<<endl;
                                //std::cout<<"相对距离  "<<relative_distance_x<<endl;
                               }



                        if(pkt->getSpeed()==0&&mobility->getCurrentSpeed().x==0)
                            std::cout<<"两辆车的距离   :"<<pkt->getCur_position_tx()-mobility->getCurrentPosition().x<<endl;
                        //iiii+=1;<!--
                       //std::cout<<"相对距离  "<<relative_distance_x<<endl;
                        //std::cout<<"相对速度"<<relative_speed<<endl;


                        //std::cout<<"当前vehicle1的减速度为  "<<brake/10000<<endl;
                        //std::cout<<mobility->getExternalId().c_str()<<"  "<<vehicle_2_speed_x-brake/10000<<endl;*/
                    }
                        /*if(Tx<=3.6 && Tx>=0)
                            {
                                 getParentModule()->getDisplayString().updateWith("r=80,pink");
                                 bubble("the vehicle will collide");
                                 traciVehicle->setColor(TraCIColor(0, 255, 0, 255));//后车收到“即将碰撞”的消息后变为绿色
                            }
                        if(Tx<=2.0 && Tx>=0)
                            {
                                 EV<<"setSpeed 0 time is "<<simTime()<<endl;
                             lastSpeed    traciVehicle->setSpeed(0);  //vehicle_2刹车
                                 traciVehicle->getWidth();   //获取车宽
                                 traciVehicle->getLength();  //获取车长
                                 EV<<"traciVehicle->getWidth()"<<traciVehicle->getWidth();
                            }*/


                //两辆车在不同车道时
                    if(relative_distance_y != 0)
                    {
                        bubble("the vehicle is safe");
                    }
                }
            }
        }

        // emit statistics
        simtime_t delay = simTime()-pkt->getTimestamp();
        emit(delay_, delay);
        emit(rcvdMsg_, (long)1);

        EV << "Mode4App::handleMessage - Packet received: SeqNo[" << pkt->getSno() << "] Delay[" << delay << "]" << endl;

        delete msg;
    }
}

void FCW_bMode4Appl::handleSelfMessage(cMessage* msg)
{
    if (!strcmp(msg->getName(), "selfSender"))
    {
        MyMesseage *packet = new MyMesseage("Alert");
        packet->setTimestamp(simTime());
        packet->setByteLength(size_);
        packet->setSno(nextSno_);
        //std::cout<<"消息的名字"<<msg->se<<endl;
        /*std::cout<<"当前移动车辆减速度为"<<packet->getSpeed_x()<<endl;
        std::cout<<"当前移动车辆减速度为"<<mobility->getCurrentSpeed().x<<endl;
        std::cout<<"当前移动车辆减速度为"<<interval_self<<endl;
        std::cout<<"当前shijian"<<simTime()<<endl;
        std::cout<<"当前xiaoxibaoshijian"<<packet->getTimestamp()<<endl;
        std::cout<<"当前移动车辆减速度为"<<vehicle_cur_decel<<endl;*/

        vehicle_id_tx = mobility->getExternalId();

        // vehilce_curSpeed_tx =mobility->getCurrentSpeed().x;
        double vehicle_curPosition_tx = mobility->getCurrentPosition().x;
        double vehicle_curPosition_ty = mobility->getCurrentPosition().y;

        EV<<"vehicle_curPosition_tx = "<<mobility->getCurrentPosition()<<" send current Speed = "<<mobility->getCurrentSpeed()<<endl;
        packet->setSpeed(vehilce_curSpeed_tx);
        packet->setVehicle_id(vehicle_id_tx.c_str());
        packet->setCur_position_tx(vehicle_curPosition_tx);
        packet->setCur_position_ty(vehicle_curPosition_ty);
        if(strcmp(packet->getVehicle_id(),"vehicle_1")==0)
        {   //std::cout<<"当前车车辆 "<<packet->getVehicle_id()<<endl;
            //std::cout<<"当前车辆1车速  ："<<vehilce_curSpeed_tx<<endl;
            //std::cout<<"当前车辆1车速  ："<<mobility->getCurrentSpeed().x<<endl;
            if(vehicle_curPosition_tx>=800)
            {
                brake_1=function_1->brake_function_1(vehilce_curSpeed_tx);
                vehicle_cur_decel=brake_1/1500;

                //std::cout<<packet->getVehicle_id()<<"jiansudu:"<<vehicle_cur_decel<<endl;

                if(vehilce_curSpeed_tx>0.1)
                {
                vehilce_curSpeed_tx= vehilce_curSpeed_tx-brake_1/1500*0.1;
                traciVehicle->setSpeed(vehilce_curSpeed_tx);
                }
                else
                {
                    traciVehicle->setSpeed(0);
                    vehilce_curSpeed_tx=0;

                }

                //std::cout<<packet->getVehicle_id()<<"    "<<vehilce_curSpeed_tx<<endl;
                //std::cout<<"当前车辆减速度为"<<vehicle_cur_decel<<endl;
            }
            else
                traciVehicle->setSpeed(25);
        }
        packet->setCur_decel(vehicle_cur_decel);//zhaofuhuan
        //std::cout<<packet->getVehicle_id()<<"速度为"<<vehilce_curSpeed_tx<<endl;
        //if(strcmp(packet->getVehicle_id(),"vehicle_2")==0)
            //if(vehicle_curPosition_tx<800)
                //traciVehicle->setSpeed(25);

        nextSno_++;

        auto lteControlInfo = new FlowControlInfoNonIp();

        lteControlInfo->setSrcAddr(nodeId_);
        lteControlInfo->setDirection(D2D_MULTI);
        lteControlInfo->setPriority(priority_);
        lteControlInfo->setDuration(duration_);
        lteControlInfo->setCreationTime(simTime());

        packet->setControlInfo(lteControlInfo);

        Mode4BaseApp::sendLowerPackets(packet);
        emit(sentMsg_, (long)1);

        scheduleAt(simTime() + period_, selfSender_);
    }
    else
        throw cRuntimeError("Mode4App::handleMessage - Unrecognized self message");
}

void FCW_bMode4Appl::finish()
{
    cancelAndDelete(selfSender_);
}

FCW_bMode4Appl::~FCW_bMode4Appl()
{
    binder_->unregisterNode(nodeId_);
}




